-- DATABASE PENGADUAN SEKOLAH
CREATE DATABASE IF NOT EXISTS pengaduan_sekolah;
USE pengaduan_sekolah;

CREATE TABLE user (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100),
    username VARCHAR(50) UNIQUE,
    password VARCHAR(100),
    role ENUM('admin','siswa')
);

CREATE TABLE kategori (
    id_kategori INT AUTO_INCREMENT PRIMARY KEY,
    nama_kategori VARCHAR(100)
);

CREATE TABLE aspirasi (
    id_aspirasi INT AUTO_INCREMENT PRIMARY KEY,
    id_user INT,
    id_kategori INT,
    isi_aspirasi TEXT,
    tanggal DATE,
    status ENUM('menunggu','diproses','selesai'),
    FOREIGN KEY (id_user) REFERENCES user(id_user) ON DELETE CASCADE,
    FOREIGN KEY (id_kategori) REFERENCES kategori(id_kategori) ON DELETE CASCADE
);

CREATE TABLE umpan_balik (
    id_feedback INT AUTO_INCREMENT PRIMARY KEY,
    id_aspirasi INT,
    isi_feedback TEXT,
    tanggal DATE,
    FOREIGN KEY (id_aspirasi) REFERENCES aspirasi(id_aspirasi) ON DELETE CASCADE
);

CREATE TABLE histori (
    id_histori INT AUTO_INCREMENT PRIMARY KEY,
    id_aspirasi INT,
    status ENUM('menunggu','diproses','selesai'),
    tanggal DATE,
    FOREIGN KEY (id_aspirasi) REFERENCES aspirasi(id_aspirasi) ON DELETE CASCADE
);

INSERT INTO user (nama, username, password, role) VALUES
('Admin Sekolah', 'admin', '123', 'admin'),
('Budi', 'budi', '123', 'siswa'),
('Siti', 'siti', '123', 'siswa');

INSERT INTO kategori (nama_kategori) VALUES
('Fasilitas Rusak'),
('Kebersihan'),
('Keamanan'),
('Lainnya');

INSERT INTO aspirasi (id_user, id_kategori, isi_aspirasi, tanggal, status) VALUES
(2, 1, 'Kursi di kelas rusak', CURDATE(), 'menunggu'),
(3, 2, 'Toilet kurang bersih', CURDATE(), 'diproses');

INSERT INTO umpan_balik (id_aspirasi, isi_feedback, tanggal) VALUES
(2, 'Sedang dibersihkan oleh petugas', CURDATE());

INSERT INTO histori (id_aspirasi, status, tanggal) VALUES
(1, 'menunggu', CURDATE()),
(2, 'diproses', CURDATE());