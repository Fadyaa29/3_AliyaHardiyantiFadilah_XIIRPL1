<?php
session_start();

// hapus semua session
$_SESSION = [];
session_unset();
session_destroy();

// redirect pakai JS (anti gagal)
echo "<script>
    alert('Berhasil logout');
    window.location='../auth/login.php';
</script>";
exit;
?>