<?php
session_start();
include '../config/koneksi.php';

// ambil input
$username = $_POST['username'];
$password = $_POST['password'];

// query login
$data = mysqli_query($conn, "SELECT * FROM user WHERE username='$username' AND password='$password'");
$cek = mysqli_num_rows($data);

if($cek > 0){

    $user = mysqli_fetch_assoc($data);

    // SIMPAN SESSION (WAJIB)
    $_SESSION['id_user'] = $user['id_user'];
    $_SESSION['nama'] = $user['nama'];
    $_SESSION['role'] = $user['role'];

    // REDIRECT SESUAI ROLE
    if($user['role'] == 'admin'){
        header("Location: ../admin/dashboard.php");
    } else {
        header("Location: ../user/dashboard.php");
    }

} else {
    header("Location: login.php?error=1");
}

?>