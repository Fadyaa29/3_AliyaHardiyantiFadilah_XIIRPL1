<?php
include '../config/koneksi.php';

if(isset($_POST['daftar'])){
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    mysqli_query($conn, "INSERT INTO user (nama, username, password, role)
    VALUES ('$nama', '$username', '$password', '$role')");

    echo "<script>
        alert('Berhasil daftar! Silakan login');
        window.location='login.php';
    </script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Akun</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>

<body class="login-body">

<div class="login-container">

    <div class="login-card">
        <h2>📝 Daftar Akun</h2>

        <form method="POST">

            <div class="input-group">
                <input type="text" name="nama" required>
                <label>Nama</label>
            </div>

            <div class="input-group">
                <input type="text" name="username" required>
                <label>Username</label>
            </div>

            <div class="input-group">
                <input type="password" name="password" required>
                <label>Password</label>
            </div>

            <select name="role" required style="margin-bottom:15px;">
                <option value="">-- Pilih Role --</option>
                <option value="user">User</option>
                <option value="admin">Admin</option>
            </select>

            <button name="daftar" class="login-btn">Daftar</button>

        </form>

        <p style="margin-top:10px;">
            Sudah punya akun? 
            <a href="login.php">Login</a>
        </p>

    </div>

</div>

</body>
</html>