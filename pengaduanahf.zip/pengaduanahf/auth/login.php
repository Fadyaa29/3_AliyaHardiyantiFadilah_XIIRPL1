<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>

<body class="login-body">

<div class="login-container">

    <div class="login-card">
        <h2>📚 Aplikasi Pengaduan</h2>
        <p class="subtitle">Sarana Sekolah</p>

        <form action="proses_login.php" method="POST">

            <!-- USERNAME -->
            <div class="input-group">
                <input type="text" name="username" required>
                <label>Username</label>
            </div>

            <!-- PASSWORD -->
            <div class="input-group">
                <input type="password" name="password" required>
                <label>Password</label>
            </div>

            <!-- BUTTON -->
            <button type="submit" class="login-btn">Login</button>

        </form>

        <!-- ERROR -->
        <?php if(isset($_GET['error'])) { ?>
            <p class="error">⚠ Username atau password salah!</p>
        <?php } ?>

        <!-- LINK REGISTER -->
        <p style="margin-top:10px;">
            Belum punya akun? 
            <a href="register.php">Daftar disini</a>
        </p>

    </div>

</div>

</body>
</html>