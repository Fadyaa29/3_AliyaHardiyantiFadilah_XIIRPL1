<?php
session_start();
include '../config/koneksi.php';

// CEK LOGIN
if(!isset($_SESSION['id_user'])){
    header("Location: ../auth/login.php");
    exit;
}

$id_user = $_SESSION['id_user'];

$data = mysqli_query($conn, "
SELECT aspirasi.*, kategori.nama_kategori 
FROM aspirasi
JOIN kategori ON aspirasi.id_kategori = kategori.id_kategori
WHERE aspirasi.id_user='$id_user'
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Status Aspirasi</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>📊 Status Aspirasi</h2>
</div>

<!-- TABEL -->
<div class="container-table">

    <table>
        <thead>
            <tr>
                <th>Kategori</th>
                <th>Isi Aspirasi</th>
                <th>Tanggal</th>
                <th>Status</th>
            </tr>
        </thead>

        <tbody>
        <?php while($d = mysqli_fetch_assoc($data)) { ?>
            <tr>
                <td><?= $d['nama_kategori'] ?></td>
                <td><?= $d['isi_aspirasi'] ?></td>
                <td><?= $d['tanggal'] ?></td>

                <td>
                    <?php if($d['status'] == 'menunggu'){ ?>
                        <span class="badge yellow">Menunggu</span>
                    <?php } elseif($d['status'] == 'diproses'){ ?>
                        <span class="badge orange">Diproses</span>
                    <?php } else { ?>
                        <span class="badge green">Selesai</span>
                    <?php } ?>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>

    <!-- BUTTON -->
    <a href="dashboard.php" class="btn-kembali">← Kembali ke Dashboard</a>

</div>

</body>
</html>