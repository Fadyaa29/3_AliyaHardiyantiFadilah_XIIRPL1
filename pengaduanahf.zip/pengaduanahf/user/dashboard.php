<?php
session_start();
include '../config/koneksi.php';

// CEK LOGIN
if(!isset($_SESSION['id_user'])){
    header("Location: ../auth/login.php");
    exit;
}

$id_user = $_SESSION['id_user'];
$nama = $_SESSION['nama'];

// HITUNG DATA KHUSUS USER
$total = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM aspirasi WHERE id_user='$id_user'"));
$menunggu = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM aspirasi WHERE id_user='$id_user' AND status='menunggu'"));
$diproses = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM aspirasi WHERE id_user='$id_user' AND status='diproses'"));
$selesai = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM aspirasi WHERE id_user='$id_user' AND status='selesai'"));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard User</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>👋 Halo, <?= $nama ?></h2>
</div>

<!-- CARD -->
<div class="container">

    <div class="card blue">
        <h3>Total Aspirasi</h3>
        <h1><?= $total ?></h1>
    </div>

    <div class="card yellow">
        <h3>Menunggu</h3>
        <h1><?= $menunggu ?></h1>
    </div>

    <div class="card orange">
        <h3>Diproses</h3>
        <h1><?= $diproses ?></h1>
    </div>

    <div class="card green">
        <h3>Selesai</h3>
        <h1><?= $selesai ?></h1>
    </div>

</div>

<!-- MENU -->
<div class="menu-user">

    <a href="kirim.php" class="menu-card">
        📝 <p>Kirim Aspirasi</p>
    </a>

    <a href="status.php" class="menu-card">
        📊 <p>Status Aspirasi</p>
    </a>

    <a href="../auth/logout.php" class="menu-card logout">
        🚪 <p>Logout</p>
    </a>

</div>

</body>
</html>