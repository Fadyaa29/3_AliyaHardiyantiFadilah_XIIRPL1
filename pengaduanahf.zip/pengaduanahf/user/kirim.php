<?php
session_start();
include '../config/koneksi.php';

// CEK LOGIN
if(!isset($_SESSION['id_user'])){
    header("Location: ../auth/login.php");
    exit;
}

if(isset($_POST['kirim'])){
    $id_user = $_SESSION['id_user'];
    $id_kategori = $_POST['id_kategori'];
    $isi = $_POST['isi'];

    // INSERT DATA (AMAN)
    mysqli_query($conn, "INSERT INTO aspirasi 
    (id_user, id_kategori, isi_aspirasi, tanggal, status)
    VALUES ('$id_user', '$id_kategori', '$isi', NOW(), 'menunggu')");

    echo "<script>
        alert('Aspirasi berhasil dikirim!');
        window.location='dashboard.php';
    </script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Kirim Aspirasi</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>📝 Kirim Aspirasi</h2>
</div>

<!-- FORM -->
<div class="form-container">

    <div class="form-card">

        <h3>Silakan tulis aspirasi kamu</h3>

        <form method="POST">

            <!-- KATEGORI -->
            <label>Kategori</label>
            <select name="id_kategori" required>
                <option value="">-- Pilih Kategori --</option>
                <?php
                $kategori = mysqli_query($conn, "SELECT * FROM kategori");
                while($k = mysqli_fetch_assoc($kategori)){
                ?>
                    <option value="<?= $k['id_kategori'] ?>">
                        <?= $k['nama_kategori'] ?>
                    </option>
                <?php } ?>
            </select>

            <!-- ISI -->
            <label>Isi Aspirasi</label>
            <textarea name="isi" rows="5" placeholder="Tulis aspirasi kamu di sini..." required></textarea>

            <!-- BUTTON -->
            <button name="kirim">Kirim Aspirasi</button>

        </form>

        <a href="dashboard.php" class="btn-kembali">← Kembali</a>

    </div>

</div>

</body>
</html>