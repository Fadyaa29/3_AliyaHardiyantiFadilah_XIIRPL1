<?php
session_start();
include '../config/koneksi.php';

// CEK LOGIN
if(!isset($_SESSION['id_user'])){
    header("Location: ../auth/login.php");
    exit;
}

// DATA
$total = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM aspirasi"));
$menunggu = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM aspirasi WHERE status='menunggu'"));
$diproses = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM aspirasi WHERE status='diproses'"));
$selesai = mysqli_num_rows(mysqli_query($conn, "SELECT * FROM aspirasi WHERE status='selesai'"));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <div class="nav-left">
        <h2>📊 Dashboard Admin</h2>
    </div>

    <div class="nav-right">
        <span class="admin-name">👤 <?= $_SESSION['nama']; ?></span>

        <!-- NOTIF -->
        <div class="notif">
            🔔 <span id="notif-count">0</span>
        </div>

        <a href="../auth/logout.php" class="btn-logout">Logout</a>
    </div>
</div>

<!-- CARD -->
<div class="container">

    <div class="card blue">
        <h3>Total Aspirasi</h3>
        <h1><?= $total ?></h1>
    </div>

    <div class="card yellow">
        <h3>Menunggu</h3>
        <h1><?= $menunggu ?></h1>
    </div>

    <div class="card orange">
        <h3>Diproses</h3>
        <h1><?= $diproses ?></h1>
    </div>

    <div class="card green">
        <h3>Selesai</h3>
        <h1><?= $selesai ?></h1>
    </div>

</div>

<!-- MENU -->
<div class="menu-card-container">

    <a href="data_aspirasi.php" class="menu-card">
        📋
        <p>Data Aspirasi</p>
    </a>

</div>

<!-- AUDIO NOTIF -->
<audio id="notifSound" src="../assets/notif.mp3"></audio>

<script>
let lastCount = 0;

function loadNotif() {
    fetch('notif.php')
    .then(res => res.text())
    .then(data => {
        let count = parseInt(data);

        if(count > lastCount){
            document.getElementById("notifSound").play();
        }

        lastCount = count;
        document.getElementById("notif-count").innerHTML = count;
    });
}

// pertama
loadNotif();

// auto refresh
setInterval(loadNotif, 5000);
</script>

<!-- AUDIO NOTIF -->
<audio id="notifSound" src="../assets/notif.mp3"></audio>

<script>
let lastCount = 0;

function loadNotif() {
    fetch('notif.php')
    .then(response => response.text())
    .then(data => {
        let count = parseInt(data) || 0;

        document.getElementById("notif-count").innerHTML = count;

        if(count > lastCount){
            document.getElementById("notifSound").play();
        }

        lastCount = count;
    })
    .catch(error => console.log("Error notif:", error));
}

// pertama kali
loadNotif();

// ulang tiap 3 detik
setInterval(loadNotif, 3000);
</script>

</body>
</html>
