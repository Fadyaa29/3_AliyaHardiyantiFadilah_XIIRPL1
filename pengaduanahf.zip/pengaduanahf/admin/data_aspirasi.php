<?php
session_start();
include '../config/koneksi.php';

// CEK LOGIN ADMIN
if(!isset($_SESSION['id_user'])){
    header("Location: ../auth/login.php");
    exit;
}

$data = mysqli_query($conn, "
SELECT aspirasi.*, user.nama, kategori.nama_kategori 
FROM aspirasi
JOIN user ON aspirasi.id_user = user.id_user
JOIN kategori ON aspirasi.id_kategori = kategori.id_kategori
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Aspirasi</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>📋 Data Aspirasi</h2>
</div>

<!-- TOP BAR -->
<div class="top-bar">
    <a href="dashboard.php" class="btn-kembali">← Dashboard</a>
</div>

<!-- TABEL -->
<div class="container-table">

    <table>
        <thead>
            <tr>
                <th>Nama</th>
                <th>Kategori</th>
                <th>Isi Aspirasi</th>
                <th>Tanggal</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
        <?php while($d = mysqli_fetch_assoc($data)) { ?>
            <tr>
                <td><?= $d['nama'] ?></td>
                <td><?= $d['nama_kategori'] ?></td>
                <td><?= $d['isi_aspirasi'] ?></td>
                <td><?= $d['tanggal'] ?></td>

                <td>
                    <?php if($d['status'] == 'menunggu'){ ?>
                        <span class="badge yellow">Menunggu</span>
                    <?php } elseif($d['status'] == 'diproses'){ ?>
                        <span class="badge orange">Diproses</span>
                    <?php } else { ?>
                        <span class="badge green">Selesai</span>
                    <?php } ?>
                </td>

                <td>
                    <a href="detail.php?id=<?= $d['id_aspirasi'] ?>" class="btn">Detail</a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>

</div>

</body>
</html>