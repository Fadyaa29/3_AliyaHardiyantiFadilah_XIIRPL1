<?php
include '../config/koneksi.php';

$id = $_GET['id'];

$data = mysqli_fetch_assoc(mysqli_query($conn, "
SELECT aspirasi.*, user.nama, kategori.nama_kategori 
FROM aspirasi
JOIN user ON aspirasi.id_user = user.id_user
JOIN kategori ON aspirasi.id_kategori = kategori.id_kategori
WHERE aspirasi.id_aspirasi='$id'
"));

if(isset($_POST['update'])){
    $status = $_POST['status'];
    mysqli_query($conn, "UPDATE aspirasi SET status='$status' WHERE id_aspirasi='$id'");
    header("Location: data_aspirasi.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Detail Aspirasi</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>

<body>

<!-- NAVBAR -->
<div class="navbar">
    <h2>📄 Detail Aspirasi</h2>
</div>

<!-- CARD -->
<div class="detail-container">

    <div class="detail-card">

        <h3><?= $data['nama'] ?></h3>

        <p><b>Kategori:</b> <?= $data['nama_kategori'] ?></p>
        <p><b>Tanggal:</b> <?= $data['tanggal'] ?></p>

        <p><b>Isi Aspirasi:</b></p>
        <div class="isi-box">
            <?= $data['isi_aspirasi'] ?>
        </div>

        <!-- STATUS -->
        <p><b>Status:</b>
            <?php if($data['status'] == 'menunggu'){ ?>
                <span class="badge yellow">Menunggu</span>
            <?php } elseif($data['status'] == 'diproses'){ ?>
                <span class="badge orange">Diproses</span>
            <?php } else { ?>
                <span class="badge green">Selesai</span>
            <?php } ?>
        </p>

        <!-- FORM UPDATE -->
        <form method="POST" class="form-update">
            <select name="status">
                <option value="menunggu" <?= $data['status']=='menunggu'?'selected':'' ?>>Menunggu</option>
                <option value="diproses" <?= $data['status']=='diproses'?'selected':'' ?>>Diproses</option>
                <option value="selesai" <?= $data['status']=='selesai'?'selected':'' ?>>Selesai</option>
            </select>

            <button name="update">Update Status</button>
        </form>

        <!-- BUTTON -->
        <a href="data_aspirasi.php" class="btn-kembali">← Kembali</a>

    </div>

</div>

</body>
</html>